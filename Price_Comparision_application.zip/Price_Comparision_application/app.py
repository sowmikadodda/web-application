from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os
import uuid
from PIL import Image
from transformers import pipeline

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-key-change-in-production')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///dealcheck.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(20), nullable=True)
    date_of_birth = db.Column(db.Date, nullable=True)
    address = db.Column(db.Text, nullable=True)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    image_path = db.Column(db.String(300), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

@app.route('/')
def landing():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        phone = request.form.get('phone', '').strip()
        dob = request.form.get('date_of_birth', '')
        address = request.form.get('address', '').strip()
        
        if not username or len(username) < 3:
            flash('Username must be at least 3 characters')
            return render_template('register.html')
        
        if not email or '@' not in email:
            flash('Valid email required')
            return render_template('register.html')
            
        if not password or len(password) < 6:
            flash('Password must be at least 6 characters')
            return render_template('register.html')
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists')
            return render_template('register.html')
            
        if User.query.filter_by(email=email).first():
            flash('Email already registered')
            return render_template('register.html')
        
        try:
            from datetime import datetime
            dob_date = None
            if dob:
                dob_date = datetime.strptime(dob, '%Y-%m-%d').date()
            
            user = User(
                username=username, 
                email=email,
                password_hash=generate_password_hash(password),
                phone=phone if phone else None,
                date_of_birth=dob_date,
                address=address if address else None
            )
            db.session.add(user)
            db.session.commit()
            
            session['user_id'] = user.id
            session['username'] = user.username
            return redirect(url_for('dashboard'))
        except Exception as e:
            db.session.rollback()
            flash('Registration failed. Please try again.')
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        
        if not username or not password:
            flash('Username and password required')
            return render_template('login.html')
        
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            session['user_id'] = user.id
            session['username'] = user.username
            return redirect(url_for('dashboard'))
        flash('Invalid username or password')
    
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('landing'))

@app.route('/search', methods=['POST'])
def search():
    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if file and allowed_file(file.filename):
        try:
            original_filename = secure_filename(file.filename)
            filename = str(uuid.uuid4()) + '.' + original_filename.rsplit('.', 1)[1].lower()
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            
            file.save(filepath)
            product_name = detect_product_name(filepath)
            
            product = Product(name=product_name, image_path=filepath, 
                            user_id=session['user_id'])
            db.session.add(product)
            db.session.commit()
            
            return jsonify({
                'success': True,
                'product_name': product_name,
                'image_url': url_for('static', filename=f'uploads/{filename}')
            })
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': 'Upload failed'}), 500
    
    return jsonify({'error': 'Invalid file type'}), 400

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'png', 'jpg', 'jpeg', 'gif'}

# Initialize object detection pipeline
object_detector = None

def get_detector():
    global object_detector
    if object_detector is None:
        object_detector = pipeline("object-detection", model="facebook/detr-resnet-50")
    return object_detector

def detect_product_name(image_path):
    # First check filename (most reliable for phones)
    filename = os.path.basename(image_path).lower()
    
    # Immediate phone detection from filename
    if any(word in filename for word in ['iphone', 'phone', 'mobile', 'smartphone']):
        return "Mobile Phone"
    
    # Check aspect ratio (phones are typically tall/narrow)
    try:
        with Image.open(image_path) as img:
            width, height = img.size
            aspect_ratio = width / height if height > 0 else 1
            
            # Phone aspect ratios: portrait (0.4-0.7) or landscape (1.4-2.5)
            if 0.4 <= aspect_ratio <= 0.7 or 1.4 <= aspect_ratio <= 2.5:
                return "Mobile Phone"
    except:
        pass
    
    # Try AI detection as backup
    try:
        detector = get_detector()
        image = Image.open(image_path)
        results = detector(image)
        
        if results:
            # Check for phone-related objects
            for result in results:
                label = result['label'].lower()
                confidence = result['score']
                
                if any(keyword in label for keyword in ['cell phone', 'mobile phone', 'phone']):
                    return f"Mobile Phone (AI: {confidence:.2f})"
            
            # Get best detection
            best_result = max(results, key=lambda x: x['score'])
            label = best_result['label']
            confidence = best_result['score']
            
            product_mapping = {
                'cell phone': 'Mobile Phone',
                'laptop': 'Laptop Computer',
                'tv': 'Television',
                'book': 'Book',
                'bottle': 'Bottle',
                'cup': 'Cup',
                'chair': 'Chair',
                'clock': 'Clock'
            }
            
            product_name = product_mapping.get(label.lower(), label.title())
            return f"{product_name} ({confidence:.2f})"
    
    except Exception:
        pass
    
    return "Mobile Phone"

if __name__ == '__main__':
    with app.app_context():
        # Drop all tables and recreate to avoid schema conflicts
        db.drop_all()
        db.create_all()
    app.run(debug=True)